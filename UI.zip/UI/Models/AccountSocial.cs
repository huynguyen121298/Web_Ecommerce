﻿namespace UI.Models
{
    public class AccountSocial
    {
        public string AccountId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string IdToken { get; set; }
    }
}