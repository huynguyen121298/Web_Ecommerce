﻿namespace UI.Models
{
    public class AuthenticationEmail
    {
        public string Email { get; set; }
        public string AuthenticationCode { get; set; }
    }
}